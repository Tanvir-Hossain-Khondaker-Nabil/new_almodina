<?php

return [
    'save' => 'Save',
    'cancel' => 'Cancel',
    'delete' => 'Delete',
    'edit' => 'Edit',
    'create' => 'Create',
    'update' => 'Update',
    'search' => 'Search',
    'back' => 'Back',
    'next' => 'Next',
    'previous' => 'Previous',
    'tk' => 'tk'
];