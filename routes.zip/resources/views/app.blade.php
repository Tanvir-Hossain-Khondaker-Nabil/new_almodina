<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Al Modina</title>
    <link rel="shortcut icon" href="https://i.ibb.co.com/t0bPR3c/output-onlinepngtools-12-1.png" type="image/x-icon">
    @routes
    @viteReactRefresh
    @vite('resources/js/app.jsx')
    @inertiaHead


    <link rel="stylesheet" href="{{ asset('build/assets/app-CDvlLzVr.css') }}">
    <script src="{{ asset('build/assets/app-Cz7arox5.js') }}" type="module"></script>
</head>


<style>
    ::-webkit-scrollbar-thumb {
        width: 0px
    }
</style>

<body>
    @inertia
</body>

</html>
